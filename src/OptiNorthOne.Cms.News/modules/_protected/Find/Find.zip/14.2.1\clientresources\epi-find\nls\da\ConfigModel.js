//>>built
define("epi-find/nls/da/ConfigModel",{"configErrorMessage":"Der opstod en fejl ved læsning af konfigurationen."});