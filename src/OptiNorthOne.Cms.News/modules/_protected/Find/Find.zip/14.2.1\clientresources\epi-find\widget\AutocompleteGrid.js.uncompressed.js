define("epi-find/widget/AutocompleteGrid", [
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/Evented",
    "dojo/on",
    "dojo/when",
    "dojo/dom-style",

    "dijit/MenuItem",

    "dgrid/Grid",
    "dgrid/extensions/DnD",
    "dgrid/extensions/DijitRegistry",

    "epi/shell/widget/ContextMenu",
    "epi/shell/dgrid/Formatter",
    "epi-cms/dgrid/formatters",

    "epi-saas-base/widgets/_NotificationMixin",
    "epi-saas-base/widgets/_GridContextMenuMixin",
    "epi-saas-base/widgets/_GridMoreMixin",
    "epi-saas-base/widgets/_AutoLoadScrollMixin",

    "dojo/i18n!./nls/Autocomplete"
],
    function(
        declare,
        lang,
        Evented,
        on,
        when,
        domStyle,
        MenuItem,
        Grid,
        DnD,
        DijitRegistry,
        ContextMenu,
        Formatter,
        formatters,
        _NotificationMixin,
        _GridContextMenuMixin,
        _GridMoreMixin,
        _AutoLoadScrollMixin,
        i18n
        ) {
        // module:
        //      epi-find/widget/AutocompleteGrid

       return declare([Grid, _GridMoreMixin, _AutoLoadScrollMixin, DnD, Formatter, _GridContextMenuMixin, _NotificationMixin], {
            // summary:
            //    Autocomplete grid.
            constructor: function() {
                // Sets the loader (#loadNextPage, available in _GridMoreMixn) to be used by the _AutoLoadScrollMixin
                this.loader = lang.hitch(this, this.loadNextPage);
            },
            i18n: i18n,
            showHeader: true,
            margin: 140,
            noDataMessage: i18n.noData,
            keepScrollPosition: true,
            columns: {
                query: {
                    label: i18n.fields_phrase,
                    sortable: false,
                    className:"epi-grid--30"
                },

                context: {
                    label: " ",
                    sortable: false,
                    className: "epi-grid--10",
                    formatter: function() {
                        return formatters.menu({title: i18n.contextMenuTitle});
                    }
                }
            },

            postCreate: function() {
                var self = this,
                    getCurrentItem = function(context) {
                        var row = self.getRow(context);
                        return encodeURIComponent(row.id);
                    };

                this.inherited(arguments);
                this._sort = [
                    {attribute:"priority", descending: true},
                    {attribute:"timestamp", descending: true}
                ];

                this.editMenuItem = new MenuItem({
                    label: i18n.actions_edit,
                    onClick: function () {
                        var id = getCurrentItem(this);
                        self.onEdit({grid: self, id: encodeURIComponent(id)});
                    }
                });

                this.deleteMenuItem = new MenuItem({
                    label: i18n.actions_delete,
                    onClick: function () {
                        var id = getCurrentItem(this);
                        self.showConfirmation({
                            title: i18n.deleteTitle,
                            message: i18n.areYouSureDelete,
                            confirmActionText: i18n.buttons_confirmDelete,
                            cancelActionText: i18n.buttons_cancelDelete,
                            action: function() {
                                when(self.model.remove(id), function(){
                                        self.showSuccess(i18n.deletedMessage);
                                        self.refresh();
                                    },
                                    function(error){
                                        self.showError(error);
                                        self.refresh();
                                    }
                                );
                            }
                        });
                    }
                });

                this.contextMenu = new ContextMenu({});

                // Creating menu structure
                this.contextMenu.addChild(this.editMenuItem);
                this.contextMenu.addChild(this.deleteMenuItem);

                this.own(
                    this.editMenuItem,
                    this.deleteMenuItem,
                    this.on("dgrid-error", function(event) {
                        self.showErrorInGrid(event.error);
                    })
                );
                if (this.store.isInstanceOf(Evented)) {
                    this.own(
                        on(this.store, "refresh", function() {
                            self.refresh();
                        }),
                        on(this.store, "dndComplete", function() {
                            self.showSuccess(i18n.priorityChangedMessage);
                        }),
                        on(this.store, "dndError", function(error) {
                            self.showError(error);
                        })
                    );
                }

            },

            onEdit: function(args) {
                // summary:
                //      Callback for edit action
                // args: Object
                //      Callback arguments: args.grid - reference to the grid, args.id - selected item ID
            }
        });
    });
