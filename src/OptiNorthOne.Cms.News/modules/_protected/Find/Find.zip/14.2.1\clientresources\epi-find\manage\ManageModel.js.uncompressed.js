﻿define("epi-find/manage/ManageModel", [
    "dojo/_base/declare",
    "dojo/_base/config",
    "dojo/Stateful",

    "dojo/store/Observable",
    "./RelatedQueriesModel",
    "./AutocompleteModel",

    "dijit/Destroyable"
],
function (
    declare,
    config,
    Stateful,
    Observable,
    RelatedQueriesModel,
    AutocompleteModel,
    Destroyable
    ) {

    return declare([Stateful, Destroyable], {
        // summary:
        //      Manage model.

        topQueryStore: null,
        queryStore: null,
        topHitStore: null,
        nullQueryStore: null,
        relatedQueriesStore: null,
        autocompleteStore: null,

        relatedQueriesModel: null,
        autocompleteModel: null,

        constructor: function () {
            this.queryStore = config.dependencies["epi-find.QueryStore"];
            this.topQueryStore = config.dependencies["epi-find.TopQueryStore"];
            this.topHitStore = config.dependencies["epi-find.TopHitStore"];
            this.nullQueryStore = config.dependencies["epi-find.NullQueryStore"];
            this.relatedQueriesStore = config.dependencies["epi-find.RelatedQueries"];
            this.autocompleteStore = config.dependencies["epi-find.Autocomplete"];

            this.relatedQueriesModel = new RelatedQueriesModel({
                store: this.relatedQueriesStore
            });

            this.autocompleteModel = new AutocompleteModel({
                store: new Observable(this.autocompleteStore)
            });
        },

        init: function () {
        }
    });
});
