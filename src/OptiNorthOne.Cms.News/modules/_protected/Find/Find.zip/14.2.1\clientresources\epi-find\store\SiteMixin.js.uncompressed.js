define("epi-find/store/SiteMixin", [
    "dojo/_base/declare",
    "dojo/_base/lang"
],
function (declare, lang) {
    return declare(null, {
        // siteParameter: string
        //      The query parameter to send when querying for a specific site.
        siteParameter: null,

        // sitePrefix: string
        //      An optional prefix of the site value.
        sitePrefix: "",

        // emptySite: string
        //      Value to pass when site is null.
        emptySite: null,

        // addEmptyToQuery: bool
        //      Indicates if emptySite should always be added to the query using the pipe syntax,
        //      even if site is specified
        addEmptyToQuery: false,

        // site: String
        //      The identifying string for the site
        site: null,

        // addToObject: Boolean
        //      Indicates that additional parameters should be added to the object when it is about to be saved
        addToObject: false,

        query: function(query, options) {
            // Override any query function to add the site parameter
            var newQuery = this._addSite(lang.clone(query), this.addEmptyToQuery);
            return this.inherited(arguments, [newQuery, options]);
        },

        put: function(object, options){
            if (this.addToObject) {
                object = this._addSite(object);
            }
            return this.inherited(arguments, [object, options]);
        },

        _addSite: function(query, /*bool*/ addEmpty) {
            // summary:
            //      This method adds information about the current site
            //      to the specified `query` object
            // query: Object
            //      Entity or query where the site parameter should be set
            // addEmpty: Boolean
            //      Indicates that value of `emptySite` property should be
            //      added to the `query` parameter
            // tags:
            //      private
            if (!this.siteParameter || !this.sitePrefix) {
                return query;
            }
            var siteQueryValue, existingParam, siteValues = [];
            query = query || {};
            if (this.emptySite && (addEmpty || !this.site)) {
                siteValues.push(this.sitePrefix + this.emptySite);
            }
            if (this.site) {
                siteValues.push(this.sitePrefix + this.site);
            }

            if (siteValues.length === 0)
            {
                return query;
            }

            siteQueryValue = siteValues.join("|");
            existingParam = query[this.siteParameter];
            if (existingParam) {
                if (existingParam instanceof Array) {
                    var exists = false;
                    for (var i=0; i < existingParam.length; i++) {
                        if (existingParam[i].indexOf(this.sitePrefix) === 0) {
                            existingParam[i] = siteQueryValue;
                            exists = true;
                            break;
                        }
                    }
                    if (!exists) {
                        query[this.siteParameter].push(siteQueryValue);
                    }
                } else {
                    query[this.siteParameter] = [existingParam, siteQueryValue];
                }
            } else {
                query[this.siteParameter] = [siteQueryValue];
            }

            return query;
        },

        setSite: function(/* object */ site) {
            // Summary:
            //      Sets the site to a new value, null means all sites.
            var oldSite = this.site;

            this.site = site;

            if (site !== oldSite) {
                this.onSiteChange(oldSite, site);
            }
        },

        // Overridden in children.
        onSiteChange: function(oldSite, newSite) {
        }
    });
});