//>>built
define("epi-find/nls/zh/ConfigModel",{"configErrorMessage":"错误读取配置。"});