﻿define("epi-find/store/SearchWithWeights", [
        "dojo/_base/lang",
        "dojo/Deferred",
        "dojo/json",
        "dojo/_base/declare",
        "dojo/store/util/QueryResults",
        "epi/shell/store/JsonRest",
        "epi-saas-base/RetryableXhrWrapper"
],
function (lang, Deferred, JSON, declare, QueryResults, JsonRest, RetryableXhrWrapper) {
    return declare(JsonRest, {
        // summary:
        //		This is a basic store for RESTful communicating with searchwithweights

        constructor: function (options) {
            this.xhrHandler = new RetryableXhrWrapper(options ? options.handlerOptions : null);
            this.headers = {"Content-Type": "application/json"};
            declare.safeMixin(this, options);
        },

        // idProperty: String
        //		Indicates the property to use as the identity property. The values of this
        //		property should be unique.
        idProperty: "Url",

        query: function (query, options) {
            options = options || {};
            query = query || {};

            if (options.count) {
                query.size = options.count;
            }
            if (options.start) {
                query.from = options.start;
            }
            var results;
            if (query.q) {
                results = this.inherited(arguments);
            } else {
                var headers = lang.mixin({ Accept: this.accepts }, this.headers, options.headers);
                results = this.xhrHandler.xhr("POST", {
                    url: this.target,
                    postData: JSON.stringify(query),
                    handleAs: "json",
                    headers: headers
                });
            }

            var queryResults = new Deferred();
            results.then(function(data) {
                queryResults.resolve(data.hits);
            }, function(error) {
                queryResults.reject(error);
            });

            queryResults.total = results.then(function (data) {
                return data.total;
            });

            queryResults.query = query;

            return QueryResults(queryResults);
        }
    });

});