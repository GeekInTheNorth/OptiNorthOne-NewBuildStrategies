require({cache:{
'url:epi-cms/contentediting/editors/templates/LinkItemEditor.html':"﻿<div data-dojo-attach-point=\"inputContainer\" class=\"dijitReset dijitInputField dijitInline epi-resourceInputContainer\" id=\"widget_${id}\">\r\n    <div data-dojo-attach-point=\"displayNode, dropAreaNode, stateNode\" class=\"dijit dijitReset dijitInline dijitInlineTable dijitLeft dijitTextBox displayNode\">\r\n        <div class=\"dijitReset dijitLeft dijitInputField dijitInputContainer\">\r\n            <div data-dojo-attach-point=\"contentSelectorContainer\" class=\"contentSelectorContainer\"></div>\r\n            <div class=\"epi-linkItemContainer\">\r\n                <span class=\"epi-iconLink\"></span>\r\n                <span data-dojo-attach-point=\"iconNode\"></span>\r\n                <div data-dojo-attach-point=\"resourceName\" class=\"dijitInline epi-resourceName dojoxEllipsis\" >\r\n                    <span data-dojo-attach-point=\"selectedContentNameNode\"></span>\r\n                    <span data-dojo-attach-point=\"selectedContentLinkNode\"></span>\r\n                </div>\r\n                <div data-dojo-attach-point=\"extraIconsContainer\" class=\"epi-extraIconsContainer\">\r\n                    <span data-dojo-attach-point=\"iconNodeMenu\" class=\"epi-iconContextMenu\" />\r\n                </div>\r\n                <div data-dojo-attach-point=\"clearButton\"></div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>\r\n"}});
define("epi-cms/contentediting/editors/LinkItemEditor", [
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/aspect",
    "dojo/on",
    "epi-cms/widget/_SelectorBase",
    "epi-cms/contentediting/command/ItemEdit",
    "epi-cms/contentediting/command/BlockRemove",
    "epi-cms/contentediting/viewmodel/LinkItemModel",
    "epi-cms/contentediting/viewmodel/ItemCollectionViewModel",
    "epi-cms/widget/SingleLinkEditor",
    "epi/shell/widget/ContextMenu",
    "epi-cms/dgrid/formatters",
    // Resources
    "dojo/text!./templates/LinkItemEditor.html",
    "epi/i18n!epi/cms/nls/episerver.cms.widget.editlink"
], function (
    declare,
    lang,
    aspect,
    on,
    _SelectorBase,
    ItemEditCommand,
    RemoveCommand,
    LinkItemModel,
    ItemCollectionViewModel,
    SingleLinkEditor,
    ContextMenu,
    formatters,
    // Resources
    template,
    resource
) {

    return declare([_SelectorBase], {

        resource: resource,

        baseClass: "epi-linkItemEditor",

        templateString: template,

        itemModelType: LinkItemModel,

        postCreate: function () {
            this.inherited(arguments);

            if (this.customTypeIdentifier) {
                this.allowedDndTypes.unshift(this.customTypeIdentifier);
            }

            this.own(
                this.model = this.model || new ItemCollectionViewModel(this.value ? [this.value] : [], {
                    itemModelType: this.itemModelType,
                    readOnly: this.readOnly
                }),
                this.model.on("changed", function () {
                    var value = this.get("value");
                    value = value === undefined ? null : value;
                    this._updateDisplayNode(value ? Object.assign({},value, {name: value.text}) : null);
                    this.onChange(value);
                }.bind(this))
            );

            this.model.on("initCompleted", this._initialize.bind(this));
            this._initialize();
            this._setupContextMenu();
        },

        postMixInProperties: function () {
            this.inherited(arguments);

            this.actionsNodeOptions = {
                settings: {
                    label: resource.buttonlabel
                }
            };
        },

        _updateDisplayNode: function (content) {
            // summary:
            //      Override to set icon class

            this.inherited(arguments);

            // Reset icon class
            this.iconNode.className = "";
            if (content) {
                var additionalClass = formatters.additionalClassByFilename(content.text);
                this.iconClass = formatters.contentIconClass(content.typeIdentifier, additionalClass);
                this.iconNode.className = this.iconClass;
            }
        },

        _initialize: function () {
            var value = this.get("value");
            this.model.set("selectedItem", value);
            this._updateDisplayNode(value ? Object.assign({}, value, { name: value.text }) : null);
            this._editItemCommand && this._editItemCommand.set("model", this.model);
            this.onChange(value);
        },

        _setupContextMenu: function () {

            this._createCommands();

            this.own(
                this.contextMenu = new ContextMenu(),
                on(this.iconNodeMenu, "click", function (evt) {
                    this.contextMenu && this.contextMenu.scheduleOpen(evt.target, null, { x: evt.pageX, y: evt.pageY });
                }.bind(this))
            );
            this.contextMenu.addProvider(this);
        },

        _setupDialogSettings: function () {
            // summary:
            //      Setup settings for dialog.
            // tags:
            //      protected virtual

            this.inherited(arguments);

            this.dialogSettings = Object.assign(this.dialogSettings, {
                title: this._getTitle(),
                dialogContentClass: SingleLinkEditor
            });
        },

        _setupContentSelectorDialogSettings: function () {
            this.inherited(arguments);

            this.contentSelectorDialogSettings = Object.assign(this.contentSelectorDialogSettings, {
                modelType: this.metadata.additionalValues["modelType"]
            });
        },

        _onDialogExecute: function (linkObj) {
            //summary:
            //    Handle dialog close through executing OK, Cancel, Delete commands
            // tags:
            //    protected

            this.set("value", linkObj);
            this.onChange(linkObj);
        },

        _createCommands: function () {

            var dialogContentParams = this.commandOptions ? this.commandOptions.dialogContentParams : {};

            this._editItemCommand = new ItemEditCommand({
                isAvailable: true,
                canExecute: true,
                model: this.model,
                dialogContentParams: dialogContentParams,
                dialogContentClass: SingleLinkEditor,
                category: null
            });

            this.commands = [
                this._editItemCommand,
                new RemoveCommand({ model: this.model })
            ];

            this.commands.forEach(function (command) {
                this.own(command);
            }, this);

            this.own(
                aspect.after(this._editItemCommand, "onDialogOpen", function () {
                    this.set("isShowingChildDialog", true);
                    this.focus();
                }.bind(this)),
                aspect.after(this._editItemCommand, "onDialogHideComplete", function () {
                    this.set("isShowingChildDialog", false);
                }.bind(this)),
                aspect.after(this._editItemCommand, "onDialogExecute", function () {
                    this.set("value", this._editItemCommand.value);
                }.bind(this))
            );
        },

        _setValueAttr: function (value) {
            if (!value || (value instanceof Array) && value.length === 0) {
                value = null;
            }

            this.model && this.model.set("data", value ? [value] : []);
        },

        _getValueAttr: function () {
            if (!this.model) {
                return null;
            }

            var value = this.model.get("value");
            if (value instanceof Array && value.length === 0) {
                return null;
            }

            return value[0];
        },

        isValid: function () {
            return (!this.required || this.get("value"));
        },

        _onButtonClick: function () {
            // summary:
            //    Triggered when editor clicks on link edit button
            //    Overriden from _SelectorBase
            //
            // tags:
            //    public callback

            if (this.value && (this.value instanceof Array && this.value.length > 0)) {
                this._editItemCommand.set("value", this.value[0]);
            } else {
                this._editItemCommand.set("value", {});
            }
            this._editItemCommand.execute();
        },

        getEmptyValue: function () {
            // summary:
            //    Returns empty property value
            //    Overriden from _HasClearButton
            //
            // tags:
            //    public callback

            return null;
        },

        onDrop: function (value) {
            // summary:
            //    Triggered when something has been dropped onto the widget.
            //    Overriden from _Droppable
            //
            // tags:
            //    public callback

            this.onChange(this.get("value"));
        },

        _getTitle: function () {
            // summary:
            //      Customize base get method for title prop.
            // tags:
            //      protected

            return lang.replace(this.value ? this.resource.title.template.edit : this.resource.title.template.create, this.resource.title.action);
        }

    });
});
